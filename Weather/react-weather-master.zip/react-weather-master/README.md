## The challenge?
Create a simple weather app using Javascript/HTML/CSS that shows the current weather conditions in London, UK using the API at [Open Weather Map]
