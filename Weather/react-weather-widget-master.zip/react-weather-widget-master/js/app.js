import React from 'react';

import Weather from './components/weather';

window.React = React;

React.render(<Weather />, document.getElementById('application'));
